import requests
import socket
import time
import subprocess
import platform

# ANSI color codes
RED = "\033[31m"
BLUE = "\033[94m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RESET = "\033[0m"

def print_ascii_art():
    ascii_art = [
        "██╗   ██╗██╗██╗     ███████╗    ██████╗  █████╗ ██╗██████╗ ███████╗██████╗ ",
        "██║   ██║██║██║     ██╔════╝    ██╔══██╗██╔══██╗██║██╔══██╗██╔════╝██╔══██╗",
        "██║   ██║██║██║     █████╗      ██████╔╝███████║██║██║  ██║█████╗  ██████╔╝",
        "╚██╗ ██╔╝██║██║     ██╔══╝      ██╔══██╗██╔══██║██║██║  ██║██╔══╝  ██╔══██╗",
        " ╚████╔╝ ██║███████╗███████╗    ██║  ██║██║  ██║██║██████╔╝███████╗██║  ██║",
        "  ╚═══╝  ╚═╝╚══════╝╚══════╝    ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚═════╝ ╚══════╝╚═╝  ╚═╝"
    ]
    for line in ascii_art:
        print(RED + line + RESET)
    print(RED + "\n" + "=" * 70)
    print("credits: monker")
    print("github : https://github.com/monker133")
    print("=" * 70)
    print(YELLOW + "n/b to go to different pages\n" + RESET)

# --- Page 1 Functions ---
def webhook_sender():
    webhook_url = input("Enter Discord Webhook URL: ").strip()
    message = input("Enter message to send: ").strip()
    while True:
        try:
            count = int(input("Enter number of times to send the message: "))
            if count <= 0:
                print("Please enter a number greater than 0.")
                continue
            break
        except ValueError:
            print("Please enter a valid number.")
    for i in range(count):
        try:
            response = requests.post(webhook_url, json={"content": message})
            if response.status_code == 204:
                print(f"[{i+1}/{count}] Message sent.")
            else:
                print(f"[{i+1}/{count}] Failed. Status code: {response.status_code}")
        except Exception as e:
            print(f"Error: {e}")
        time.sleep(0.1)

def ip_pinger():
    ip = input("Enter IP to ping: ").strip()
    print(YELLOW + "Pinging... (Ctrl+C to stop)\n" + RESET)
    try:
        while True:
            result = subprocess.run(["ping", "-n" if platform.system() == "Windows" else "-c", "1", ip],
                                    capture_output=True, text=True)
            print(result.stdout)
            time.sleep(0.1)
    except KeyboardInterrupt:
        print(RED + "\nStopped pinging." + RESET)

def ip_scan():
    ip = input("Enter IP to scan: ").strip()
    print(BLUE + f"\nLooking up IP: {ip}" + RESET)
    try:
        response = requests.get(f"https://ipinfo.io/{ip}/json")
        if response.status_code == 200:
            data = response.json()
            print(GREEN + "\n--- IP Info ---")
            print(f"IP      : {data.get('ip', 'N/A')}")
            print(f"City    : {data.get('city', 'N/A')}")
            print(f"Region  : {data.get('region', 'N/A')}")
            print(f"Country : {data.get('country', 'N/A')}")
            print(f"Org     : {data.get('org', 'N/A')}")
            print(f"Loc     : {data.get('loc', 'N/A')}" + RESET)
        else:
            print(RED + "Failed to get info." + RESET)
    except Exception as e:
        print(RED + f"Error: {e}" + RESET)

def network_check():
    ip = input("Enter IP to check: ").strip()
    print(BLUE + f"\nChecking host: {ip}" + RESET)
    try:
        result = subprocess.run(["ping", "-n" if platform.system() == "Windows" else "-c", "1", ip],
                                capture_output=True, text=True)
        online = "TTL=" in result.stdout or "ttl=" in result.stdout
        print(GREEN if online else RED)
        print("--- Host Info ---")
        print(f"IP      : {ip}")
        print(f"Online  : {'Yes' if online else 'No'}")
        if online:
            for line in result.stdout.splitlines():
                if "time=" in line or "ms" in line:
                    print(f"Ping    : {line.strip()}")
                    break
        print(RESET)
    except Exception as e:
        print(RED + f"Error: {e}" + RESET)

# --- Page 2 Function ---
def port_scanner():
    target = input("Enter IP or hostname to scan: ").strip()
    print(YELLOW + f"Scanning all ports on {target}... (this may take a while)" + RESET)
    open_ports = []
    try:
        for port in range(1, 65536):
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(0.1)
                if s.connect_ex((target, port)) == 0:
                    open_ports.append(port)
                    print(GREEN + f"Port {port} is open." + RESET)
    except KeyboardInterrupt:
        print(RED + "\nScan interrupted by user." + RESET)
    except Exception as e:
        print(RED + f"Error: {e}" + RESET)

    if open_ports:
        print(GREEN + f"\nOpen ports: {open_ports}" + RESET)
    else:
        print(RED + "No open ports found." + RESET)

# --- Paging System ---
def show_page_1():
    print(BLUE + "Page 1: Tools")
    print("1: Discord Webhook Sender")
    print("2: IP Pinger")
    print("3: IP Scan (location info)")
    print("4: Network Check")

def show_page_2():
    print(BLUE + "Page 2: Advanced Tools")
    print("1: Port Scanner (full port range)")
# --- Main Loop ---
def main():
    current_page = 1
    while True:
        print_ascii_art()
        if current_page == 1:
            show_page_1()
        else:
            show_page_2()
        choice = input("\nChoose an option: ").strip().lower()

        if current_page == 1:
            if choice == "1": webhook_sender()
            elif choice == "2": ip_pinger()
            elif choice == "3": ip_scan()
            elif choice == "4": network_check()
            elif choice == "n": current_page = 2
            elif choice == "q": break
            else: print(RED + "Invalid choice." + RESET)
        else:
            if choice == "1": port_scanner()
            elif choice == "b": current_page = 1
            elif choice == "q": break
            else: print(RED + "Invalid choice." + RESET)

if __name__ == "__main__":
    main()
